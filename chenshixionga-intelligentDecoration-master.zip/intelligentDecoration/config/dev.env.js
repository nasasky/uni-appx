export default {
	// BASE_URL: "https://192.168.1.26:18011", // 朝江
	// BASE_URL: "https://192.168.1.39:18011", // 蔡伟
	
	// #ifdef MP-WEIXIN
	BASE_URL: "https://132.232.54.239:18011", 
	// #endif
	// #ifdef APP-PLUS
	BASE_URL: "http://132.232.54.239:18010",
	// #endif
	loginObj: {
		token: "a85846d0dcb783f73cd8ad6ab805e04ad3de0b84",
		hasLogin: false,
		uid: 159
		// uid: 37 // 蔡伟
	}
}
