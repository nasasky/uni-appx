export default {
	// #ifdef MP-WEIXIN
	BASE_URL: "https://132.232.54.239:18011", 
	// #endif
	// #ifdef APP-PLUS
	BASE_URL: "http://132.232.54.239:18010", 
	// #endif
}