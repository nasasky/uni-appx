<template>
	<view>
		<web-view src="https://m.ijiaol.com/index"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
			}
		},
	}
</script>

<style>
</style>
