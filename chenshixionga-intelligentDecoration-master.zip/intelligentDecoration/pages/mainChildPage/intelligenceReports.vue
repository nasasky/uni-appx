<template>
	<view class="content">
		<image class="report-img" src="http://132.232.54.239:18069/stuff/image/380783"></image>
	</view>
</template>

<script>
</script>

<style>
	.content{
		padding: 0;
	}
	.report-img{
		width: 100%;
		height: 100%;
	}
</style>
