<template>
	<view class="cus-no-data">
		<text class="def-icon">&#xe64b;</text>
		<text> 暂 无 数 据 . . . </text>
	</view>
</template>

<script>
</script>

<style>
	export default {
		name: 'cus-upload-image'
		}
</style>
