<template>
	<view class='my-color'></view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		},
		created() {

		},
	}
</script>
<style lang='scss'>
	.my-color{
		height: 14upx;
		background: repeating-linear-gradient(135deg,#95C9F1 0%,#95C9F1 5%,white 5%,white 10%, #F7918D 10%, #F7918D 15%, white 15%,white 20%);
	}
</style>
