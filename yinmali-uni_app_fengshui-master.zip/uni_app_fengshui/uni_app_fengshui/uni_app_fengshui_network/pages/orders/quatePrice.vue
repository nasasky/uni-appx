<template>
	<quate-price></quate-price>
</template>

<script>
	import quatePrice from '@/components/givePrice/givePrice.vue'
	export default {
		components:{quatePrice},
		data() {
			return {

			}
		},
		methods: {

		}
	}
</script>
<style lang='scss'>
	
</style>
