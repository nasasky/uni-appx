<template>
	<view class='manage-detail'>
		这里的详情可以跟自营订单公用，修改判断条件
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		},
		created() {

		},
	}
</script>
<style lang='scss'>
	.manage-detail {}
</style>
