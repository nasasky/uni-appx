let config = {
  restUrl: 'http://zerg.cn/api/v1/'
}

export default config