import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  template: `
    <p>
      login works!
    </p>
  `,
  styleUrls: ['./login.component.less'],
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
