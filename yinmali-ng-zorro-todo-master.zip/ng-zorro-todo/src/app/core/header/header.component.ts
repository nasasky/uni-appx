import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.less']
})
export class HeaderComponent implements OnInit {
  @Input() isCollapsed: Boolean;
  @Output() toggle = new EventEmitter<void>();
  constructor() { }

  ngOnInit() {
  }
  
  openSidebar() {
    this.toggle.emit();
  }
}
