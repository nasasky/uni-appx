import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent {
  title = 'app';
  isCollapsed = true;

  toggleCollapsed(): void {
    console.log(123123)
    this.isCollapsed = !this.isCollapsed;
  }
}
