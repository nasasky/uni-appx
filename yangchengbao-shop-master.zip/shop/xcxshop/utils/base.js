import {Config} from '../utils/config.js';
import {Token} from 'token.js';
class Base{

constructor(){
   this.baseRequestUrl = Config.restUrl;
}

  request(params, noRefetch){
  var url = this.baseRequestUrl + params.url;
  var that = this;
  if(!params.type){
    params.type = 'GET';
  }
  wx.request({
    url: url,
    data:params.data,
    method:params.type,
    header:{
      'content-type':'application/json',
      'token':wx.getStorageSync('token')
    },
    success:function(res){
      if (res.data.code == "40001") {
        wx.reLaunch({
          url: '/pages/login/login'
        })
        return;
      }
      params.sCallback(res.data);
    },
    fail:function(res){
      wx.showModal({
        title: '提示信息',
        content: '网络请求失败',
        showCancel: false,
      })
    }
  })
}

 _refetch(params){
   var token = new Token();
   token.getTokenFromServer((token)=>{
     this.request(params,true);
   });
 }

  getDataSet(event,key){
    return event.currentTarget.dataset[key];
}


}

export {Base};