class Config{

  constructor(){

  }


}

Config.restUrl = 'http://shopxcx.com/api/v1/';

export {Config};