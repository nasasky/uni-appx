import { Theme } from 'theme-model.js';
var theme = new Theme(); //实例化  主题列表对象
Page({
  data: {
  },
  
  onLoad: function (option) {
    this.data.titleName = option.name;
    this.data.id = option.id;
    this._loadData();
  },

  onReady:function(option){
      wx.setNavigationBarTitle({
        title: this.data.titleName
      })
  },

  /*加载所有数据*/
  _loadData: function () {
    /*获取单品列表信息*/
    theme.getProductsData(this.data.id, (data) => {
      this.setData({
        themeInfo: data,
      });
    });
  
  },

  onProductsItemTap: function (event) {
    var id = theme.getDataSet(event, 'id');
    wx.navigateTo({
      url: '../product/product?id=' + id,
    })
  },

  /*下拉刷新页面*/
  onPullDownRefresh: function () {
    console.log(1);
    this._loadData(() => {
      wx.stopPullDownRefresh()
    });
  },
  //分享效果
  onShareAppMessage: function () {
    return {
      title: '零食商贩 Pretty Vendor',
      path: 'pages/theme/theme?id=' + this.data.id
    }
  }
 

 

})


