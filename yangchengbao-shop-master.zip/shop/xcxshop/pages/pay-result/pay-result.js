
Page({
  data: {

  },
  onLoad: function (options) {
    console.log(options.flag);
    this.setData({
      payResult: 'true',
      id: options.id,
      from: options.from
    });
  },
  viewOrder: function () {
    console.log(1)
    wx.switchTab({
      url: "/pages/my/my"
    })
  }
}
)