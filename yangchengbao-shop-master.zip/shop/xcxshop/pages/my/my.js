// pages/my/my.js
import {My} from 'my-model.js';
import { Order } from '../order/order-model.js';
import { Address } from '../../utils/address.js';
var my = new My();
var order = new Order();
var address = new Address();
 
Page({

  /**
   * 页面的初始数据
   */
  data: {
    loadingHidden:false,
    page : 1,
    orderArr : [],
    isloaded:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onShow: function (options) {
    this._loadData();
    this._getAddressInfo();
  },
  _loadData:function(){
     my.getUserInfo((data)=>{
       console.log(data+'...');
       this.setData({
         userInfo:data
       })
     })
     this.getOrders();
  },

  getOrders:function(){
    var that = this;
    order.getOrders(this.data.page,(data)=>{
      if (data.data.length < data.per_page){
        this.data.isloaded = true;
      }
      this.data.orderArr.push.apply(this.data.orderArr,data.data);
      this.setData({
        'orderArr': this.data.orderArr
      })
    })
  },

  _getAddressInfo:function(){
    address.getAddressInfo((addressInfo)=>{
      this._bindAddressInfo(addressInfo);
    })
  },

  _bindAddressInfo:function(address){
    this.setData({
      addressInfo : address
    })
  },

  onReachBottom:function(){
    if (!this.data.isloaded){
      this.data.page++;
      this.getOrders();
    }
  },


  /*修改或者添加地址信息*/
  editAddress: function () {
    var that = this;
    wx.chooseAddress({
      success: function (res) {
        var addressInfo = {
          name: res.userName,
          mobile: res.telNumber,
          totalDetail: address.setAddressInfo(res)
        };
        that._bindAddressInfo(addressInfo);

        //保存地址
        console.log(res);
        address.submitAddress(res, (flag) => {
          if (!flag) {
            that.showTips('操作提示', '地址信息更新失败！');
          }
        });
      }
    })
  },

  showOrderDetailInfo:function(event){
    var id = my.getDataSet(event, 'id');
    this.showTip("提示信息",'别点击了，详情不想做了');
  },

  showTip: function (title, content, flag) {
    wx.showModal({
      title: title,
      content: content,
      showCancel: false,
      success: function (res) {
        if (flag) {
          wx.switchTab({
            url: 'pages/my/my',
          })
        }
      }
    })
  },

})