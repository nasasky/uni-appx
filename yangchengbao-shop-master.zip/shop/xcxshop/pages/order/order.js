// pages/order/order.js
import { Cart } from '../cart/cart-model.js';
import { Order } from 'order-model.js';
import { Address } from '../../utils/address.js';
var addressUtil = new Address();
var cart = new Cart();
var order = new Order();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id:-1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var productsArr = cart.getCartDataFromLocal(true);
    this.data.account = options.account;
    this.setData({
      'productsArr':productsArr,
      'account':options.account,
      'orderStatus':0
    })
    addressUtil.getAddressInfo((res)=>{
      this._bindAddressInfo(res);
    })
  },

  /*修改或者添加地址信息*/
  editAddress: function () {
    var that = this;
    wx.chooseAddress({
      success: function (res) {
        var addressInfo = {
          name: res.userName,
          mobile: res.telNumber,
          totalDetail: addressUtil.setAddressInfo(res)
        };
        that._bindAddressInfo(addressInfo);

        //保存地址
        console.log(res);
        addressUtil.submitAddress(res, (flag) => {
          if (!flag) {
            that.showTips('操作提示', '地址信息更新失败！');
          }
        });
      }
    })
  },

  showTips:function(title,content,flag){
    wx.showModal({
      title: title,
      content: content,
      showCancel:false,
      success:function(res){
        if(flag){
          wx.switchTab({
            url: 'pages/my/my',
          })
        }
      }
    })
  },

  /*绑定地址信息*/
  _bindAddressInfo: function (addressInfo) {
   this.setData({
     'addressInfo':addressInfo
   })
  },


  pay:function(){
    if(!this.data.addressInfo){
      this.showTips('下单提示','请填写您的收货地址');
      return ;
    }
    if(this.data.orderStatus == 0){
      this._firstTimePay();
    }else{
      this._oneMoresTimePay();
    }
  },

  _firstTimePay:function(){
    var orderInfo = [],productInfo = this.data.productsArr,order = new Order();
    for(let i=0;i<productInfo.length;i++){
      orderInfo.push({
        product_id:productInfo[i].id,
        counts:productInfo[i].counts
      });
    }
    var that = this;
    order.doOrder(orderInfo,(data)=>{
      if(data.pass){
          var id = data.order_id;
          that.data.id = id;
          that.data.fromCartFlag = false;
          //开始支付
          that._execPay(id);
      }else{
          that._orderFail(data);  // 下单失败
      }
    })
  },

  _execPay:function(id){
    if(!order.onPay){
      this.showTips('支付提示', '本产品仅用于演示，支付系统已屏蔽', true);//屏蔽支付，提示
     // this.deleteProducts(); //将已经下单的商品从购物车删除
      wx.navigateTo({
        url: '../pay-result/pay-result?id=' + id + "&flag=" + 1 + "&from=order",
      })
      return;
    }
    var that = this;
    console.log("支付去了");
    order.execPay(id,(statusCode)=>{
      if(statusCode != 0){
        that.deleteProducts();
        var flag = statusCode = 2;
        wx.navigateTo({
          url: '../pay-result/pay-result?id='+id+"&flag="+flag+"&from=order",
        })
      }
    })
  },

  //将已经下单的商品从购物车删除
  deleteProducts: function () {
    var ids = [], arr = this.data.productsArr;
    for (let i = 0; i < arr.length; i++) {
      ids.push(arr[i].id);
    }
    cart.delete(ids);
  },

  
  /*
      *下单失败
      * params:
      * data - {obj} 订单结果信息
      * */
  _orderFail: function (data) {
    wx.showModal({
      title: '提示信息',
      content: '下单失败',
      showCancel: false,
    })
  },



 


})