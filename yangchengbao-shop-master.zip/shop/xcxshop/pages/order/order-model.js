import {Base} from '../../utils/base.js';

class Order extends Base{


  constructor(){
    super();
    this._storageKeyName = 'newOrder';
  }


  doOrder(param,callback){
    var that = this;
    var allParams = {
      url : 'order',
      type : 'POST',
      data:{products:param},
      sCallback : function(data){
        that.execSetStorageSync(true);
        callback && callback(data);
      },
      eCallback :function(data){
        callback && callback(data);
      }
    };
    this.request(allParams);
  }

  execPay(orderNumber,callback){
    var allParams = {
      url : 'pay/pre_order',
      type:'post',
      data:{id:orderNumber},
      sCallback:function(data){
        var timeStamp = data.timeStamp;
        if(timeStamp){
          wx.requestPayment({
            'timeStamp': timeStamp.toString(),
            'nonceStr': data.nonceStr,
            'package': data.package,
            'signType': data.signType,
            'paySign': data.paySign,
            success:function(){
              console.log("pay1");
              callback && callcack(2);
            },
            fail:function(){
              console.log("pay2");
              callback && callcack(1);
            }
          })
        }else{
          console.log("pay3");
          callback && callback(0);
        }
      }
    }
    this.request(allParams);
  }

  getOrders(page,callback){
    var allParams = {
      url : 'order/by_user',
      data : {'page':page},
      type : 'get',
      sCallback:function(data){
        callback && callback(data);
      }
    };
    this.request(allParams);
  }


  execSetStorageSync(data){
    wx.setStorageSync(this._storageKeyName, data)
  }

}

export {Order};