<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/27
 * Time: 1:25 PM
 */
return [
    'app_id'=>'wxe1eedd3255d79030',
    'app_secret'=>'c9e83785b1368ad90bc56d24c1fd6f81',
    'login_url'=>'https://api.weixin.qq.com/sns/jscode2session?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code',

];