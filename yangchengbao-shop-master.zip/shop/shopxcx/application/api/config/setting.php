<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/23
 * Time: 12:28 AM
 */
return [
    'img_prefix'=>'http://shopxcx.com/images',
    'token_expire_in'=>7200
];