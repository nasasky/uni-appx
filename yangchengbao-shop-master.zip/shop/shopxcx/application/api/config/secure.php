<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/23
 * Time: 12:28 AM
 */
return [
    'token_salt'=>'ycbxcx6666'
];