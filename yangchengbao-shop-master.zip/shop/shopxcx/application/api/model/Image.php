<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/23
 * Time: 12:09 AM
 */
namespace  app\api\model;

class Image extends Base {

    protected $table = 'image';

    protected $hidden = ['delete_time','update_time','from'];


    public function getUrlAttr($value,$data){
        if($data['from'] == 1){
            return config("setting.img_prefix").$value;
        }else{
            return $value;
        }
    }

}