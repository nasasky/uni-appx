<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/20
 * Time: 12:03 AM
 */
namespace app\api\model;

class Address extends Base {

    protected $table = 'user_address';

    protected $hidden = ['delete_time','update_time'];

}