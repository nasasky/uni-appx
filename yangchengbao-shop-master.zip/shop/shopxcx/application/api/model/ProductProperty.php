<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/22
 * Time: 11:19 PM
 */
namespace app\api\model;

class ProductProperty extends Base {

    protected $table = 'product_property';

    protected $hidden = [
        'delete_time',
        'product_id'
    ];



}