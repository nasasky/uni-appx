<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/22
 * Time: 11:19 PM
 */
namespace app\api\model;

class ProductImage extends Base {

    protected $table = 'product_image';

    protected $hidden = [
        'delete_time',
    ];

    public function imgUrl(){
        return $this->belongsTo('Image','img_id','id');
    }



}