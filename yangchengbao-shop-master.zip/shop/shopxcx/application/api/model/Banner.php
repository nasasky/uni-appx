<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/20
 * Time: 12:03 AM
 */
namespace app\api\model;

class Banner extends Base {

    protected $table = 'banner';

    protected $hidden = ['delete_time','update_time'];

    public function items(){
        return $this->hasMany('BannerItem','banner_id','id');
    }

    public static function getBannerByID($id){
        //TODO:根据banner ID 获取banner信息
        $data = self::with(['items','items.img'])->get($id);
        return $data;
    }
}