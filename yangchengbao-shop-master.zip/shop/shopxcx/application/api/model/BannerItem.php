<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/22
 * Time: 11:19 PM
 */
namespace app\api\model;

class BannerItem extends Base {

    protected $table = 'banner_item';

    protected $hidden = ['delete_time','update_time'];

    public function img(){
        return $this->belongsTo('Image','img_id','id');
    }

}