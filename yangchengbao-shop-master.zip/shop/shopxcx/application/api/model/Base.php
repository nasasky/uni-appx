<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/23
 * Time: 12:41 AM
 */
namespace app\api\model;

use think\Model;

class Base extends Model{


}