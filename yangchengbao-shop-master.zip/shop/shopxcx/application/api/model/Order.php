<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/23
 * Time: 12:09 AM
 */
namespace  app\api\model;

class Order extends Base {

    protected $table = 'order';

    protected $hidden = ['delete_time','update_time'];

    protected $autoWriteTimestamp = true;


    public static function getOrderByUser($uid,$page = 1,$size = 10){
        $result = self::where("user_id",$uid)->order('id',"desc")->paginate($size,false,['page'=>$page]);
        return $result;
    }

}