<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/23
 * Time: 12:09 AM
 */
namespace  app\api\model;

class Theme extends Base {

    protected $table = 'theme';


    public function topicImg(){
        return $this->belongsTo('Image','topic_img_id','id');
    }

    public function headImg(){
        return $this->belongsTo('Image','head_img_id','id');
    }

    public function products(){
        return $this->belongsToMany('Product','theme_product','product_id','theme_id');
    }

    public static function  getSimpleList($ids = ''){
        $ids = explode(',',$ids);
        $result = self::with(['topicImg','headImg'])->select($ids);
        return $result;
    }

    public static function getThemeWithProduct($id){
        $theme = self::with(['products','headImg','topicImg'])->find($id);
        return $theme;
    }
}