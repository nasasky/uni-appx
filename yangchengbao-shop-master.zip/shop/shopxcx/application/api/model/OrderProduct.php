<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/23
 * Time: 12:09 AM
 */
namespace  app\api\model;

class OrderProduct extends Base {

    protected $table = 'order_product';

    protected $hidden = ['delete_time','update_time'];



}