<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/22
 * Time: 11:19 PM
 */
namespace app\api\model;

class Category extends Base {

    protected $table = 'category';

    protected $hidden = [
        'delete_time',
        'create_time',
        'update_time'
    ];

    public function img(){
        return $this->belongsTo('Image','topic_img_id','id');
    }


}