<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/11/11
 * Time: 8:13 PM
 */
namespace app\api\controller\v1;

use app\api\service\WxNotify;
use app\api\validate\IDMustBePositiveInt;
use app\api\service\Pay as PayService;
class Pay extends Base{


    public function  getPreOrder($id){
        (new IDMustBePositiveInt())->goCheck();
        $payService = new PayService($id);
        $payService->pay();
    }


    public function receiveNotify(){
        $notify = new WxNotify();
        $notify->Handle();
    }
}