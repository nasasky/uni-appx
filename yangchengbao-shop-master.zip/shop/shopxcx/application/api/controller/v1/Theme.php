<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/19
 * Time: 10:31 PM
 */
namespace app\api\controller\v1;

use app\api\validate\IDCollection;
use app\api\model\Theme as ThemeModel;
use app\api\validate\IDMustBePositiveInt;
use app\lib\exception\ThemeException;

class Theme extends Base {

    /**
     * @url /theme?ids=id1,id2,id3,...
     * @return 一组theme模型
     */
    public function  getSimpleList($ids = ''){
        (new IDCollection())->goCheck();
        $result = ThemeModel::getSimpleList($ids);
        if($result->isEmpty()){
            throw new ThemeException();
        }
        return $result;
    }

    /**
     * @param $id
     * @url /theme/:id
     */
    public function getComplexOne($id){
        (new IDMustBePositiveInt())->goCheck();
        $result = ThemeModel::getThemeWithProduct($id);
        if(!$result){
            throw new ThemeException();
        }
        return $result;
    }



}