<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/19
 * Time: 10:31 PM
 */
namespace app\api\controller\v1;

use app\api\validate\IDMustBePositiveInt;
use app\api\validate\TestValidate;
use app\lib\exception\BannerMissException;
use think\facade\Request;
use think\Validate;
use app\api\model\Banner as BannerModel;

class Banner extends Base {

    /**
     * 获取指定id的banner信息
     * url  /banner/:id
     * GET
     * @param $id banner的id号
     */
    public function getBanner($id){
         (new IDMustBePositiveInt())->goCheck();
         $banner = BannerModel::getBannerByID($id);
         if(!$banner){
             throw new BannerMissException();
         }
         return  $banner;
    }



}