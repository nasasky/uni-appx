<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/23
 * Time: 11:30 PM
 */
namespace app\api\controller\v1;

use app\api\validate\Count;
use app\api\model\Category as CategoryModel;
use app\lib\exception\CategoryException;
use app\lib\exception\ProductException;

class Category extends Base {

    /**
     * @url /product/recent
     * @return product models
     */
    public function getAllCategories(){
        $categories = CategoryModel::all([],'img');
        if($categories->isEmpty()){
            throw new CategoryException();
        }
        return $categories;
    }

}