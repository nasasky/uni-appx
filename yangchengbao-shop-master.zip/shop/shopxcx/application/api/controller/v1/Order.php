<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/28
 * Time: 1:02 PM
 */
namespace app\api\controller\v1;

use app\api\validate\IDMustBePositiveInt;
use app\api\validate\OrderPlace;
use app\lib\exception\OrderException;
use think\Controller;
use app\api\service\Token as TokenService;
use app\api\service\Order as OrderService;
use app\api\model\Order as OrderModel;

class Order extends Base {

    public function placeOrder(){
        (new OrderPlace())->goCheck();
        $products = input("post.products/a");
        $uid = \app\lib\Token::getDataForToken('id','mini');
        $orderService = new OrderService();
        $result = $orderService->place($uid,$products);
        return $result;
    }


    public function getOrderByUser($page = 1,$size=5){
        $service = new OrderService();
        $result = $service->getOrdersByUser($page,$size);
        return $result;
    }


    public function getOrderDetail($id){
        (new IDMustBePositiveInt())->goCheck();
        $orderDetail = OrderModel::get($id);
        if(!$orderDetail){
            throw new OrderException();
        }
        $orderDetail->snap_items = json_decode($orderDetail->snap_items,true);
        $orderDetail->snap_address = json_decode($orderDetail->snap_address,true);
        return $orderDetail;
    }

}