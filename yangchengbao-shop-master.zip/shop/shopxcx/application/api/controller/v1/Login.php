<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/12/9
 * Time: 2:11 PM
 */
namespace app\api\controller\v1;

use app\api\service\User;
use app\api\service\UserToken;

class Login{


    public function index($code){
         return User::miniLogin();
    }

}