<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/12/9
 * Time: 4:07 PM
 */
namespace app\api\controller\v1;

use app\lib\exception\ApiException;
use app\lib\exception\ErrorCode;
use app\lib\Token;
use think\Controller;

class Base extends  Controller {

    public function __construct()
    {
        $token = request()->header("token");
        if(!Token::validToken($token,'mini')){
            throw new ApiException(ErrorCode::$E40001);
        }
    }

}