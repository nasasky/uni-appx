<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/18
 * Time: 9:51 PM
 */
namespace app\api\controller;

use think\Db;
use think\facade\Env;
use think\Request;

class Index{

    public function index(Request $request){
        $test = Db::table("banner_item")->select();
        return "api-index-index";
    }
}