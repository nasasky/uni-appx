<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/23
 * Time: 10:18 PM
 */
namespace app\api\validate;

use think\Validate;

class OrderArray extends BaseValidate {


    protected $rule = [
        'product_id' => 'require|isPositiveInteger',
        'counts' => 'require|isPositiveInteger'
    ];


}