<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/23
 * Time: 10:18 PM
 */
namespace app\api\validate;

class Count extends BaseValidate{

    protected $rule = [
        'count'=>'isPositiveInteger|between:1,15'
    ];

    protected $message = [
        'count'=>'size必须在1-15之间'
    ];



}