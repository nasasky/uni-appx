<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/23
 * Time: 10:18 PM
 */
namespace app\api\validate;

class TokenGet extends BaseValidate{

    protected $rule = [
        'code'=>'require|isNotEmpty'
    ];

    protected $message = [
        'code'=>'没有code还想获取token，做梦吧'
    ];



}