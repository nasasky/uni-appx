<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/19
 * Time: 11:22 PM
 */
namespace app\api\validate;


class IDMustBePositiveInt extends BaseValidate {

    protected $rule = [
        'id'=>'require|isPositiveInteger',
//        'num'=>'require|in:1,2,3'
    ];

    protected $message = [
        'id'=>'id必须为正整数'
    ];
}