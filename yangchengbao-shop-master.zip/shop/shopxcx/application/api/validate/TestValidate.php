<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/19
 * Time: 10:55 PM
 */
namespace app\api\validate;

class TestValidate extends BaseValidate{

    protected $rule = [
        'name'=>'require|max:10',
        'email'=>'email'
    ];
}