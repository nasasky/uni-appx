<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/23
 * Time: 10:18 PM
 */
namespace app\api\validate;

class AddressNew extends BaseValidate{

    protected $rule = [
         'name'=>'require|isNotEmpty',
         'mobile'=>'require',
         'province'=>'require|isNotEmpty',
         'city'=>'require|isNotEmpty',
         'country'=>'require|isNotEmpty',
         'detail'=>'require|isNotEmpty'
    ];

    protected $message = [

    ];

    protected function isNotEmpty($value,$rule = '',$data = '',$field = ''){
        if(empty(trim($value))){
            return false;
        }else{
            return true;
        }
    }

}