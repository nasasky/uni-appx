<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/20
 * Time: 12:46 AM
 */
namespace app\lib\exception;

class TokenException extends BaseException{

    public $code = 401;

    public $msg = 'Token已过期或者无效';

    public $errorCode = 10001;
}