<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/21
 * Time: 9:38 PM
 */
namespace app\lib\exception;

class SuccessException{

    public $code = 201;
    public $msg = 'ok';
    public $errorCode = 0;


}