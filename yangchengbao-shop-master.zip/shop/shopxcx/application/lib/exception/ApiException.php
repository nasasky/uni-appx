<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/12/9
 * Time: 2:35 PM
 */
namespace app\lib\exception;


use think\Exception;

class ApiException extends Exception{

    public $code = 500;

    public $message = '系统错误';

    public function __construct($params = [],$msg = '')
    {
        if(!is_array($params)){
            return false;
        }
        $this->code = $params['code'] ?? 500;
        if(!$msg){
            $this->message = $params['msg'] ?? '系统错误';
        }else{
            $this->message = $msg;
        }
    }
}