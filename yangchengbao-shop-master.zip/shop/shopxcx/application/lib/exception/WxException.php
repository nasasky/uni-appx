<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/20
 * Time: 12:46 AM
 */
namespace app\lib\exception;

class WxException extends BaseException{

    public $code = 500;

    public $msg = '微信接口调用失败';

    public $errorCode = 999;
}