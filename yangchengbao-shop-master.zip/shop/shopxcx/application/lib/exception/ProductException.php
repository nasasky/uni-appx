<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/20
 * Time: 12:46 AM
 */
namespace app\lib\exception;

class ProductException extends BaseException{

    public $code = 404;

    public $msg = '商品信息不存在';

    public $errorCode = 20000;
}