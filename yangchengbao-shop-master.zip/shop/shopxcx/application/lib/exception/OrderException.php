<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/11/9
 * Time: 11:56 PM
 */
namespace app\lib\exception;
class OrderException extends BaseException{

    public $code = 404;
    public $msg = "订单不存在";
    public $errorCode = 80000;
}