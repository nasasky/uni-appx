<?php
namespace app\lib\exception;

/**
 * 错误码定义
 * code 0 错误提示
 * code 1 返回正常
 * code 500 服务器异常
 * code 400** api自定义异常
 * Class ErrorCode
 * @package App\Exceptions
 */
class ErrorCode{
    /**
     * @var token无效
     */
    public static $E40001 = ["code"=>40001,"msg"=>"token无效"];

    /**
     * 微信接口错误，提示信息单独传入，如: throw new ApiException(ErrorCode::$E40002,'{"errcode":40013,"errmsg":"invalid appid"}');
     * @var 微信接口错误
     */
    public static $E40002 = ["code"=>40002,"msg"=>"微信接口错误"];

    /**
     * @var 参数错误
     */
    public static $E40003 = ["code"=>40003,"msg"=>"参数错误"];

    /**
     * @var 操作失败
     */
    public static $E40004 = ["code"=>40004,"msg"=>"操作失败"];

}