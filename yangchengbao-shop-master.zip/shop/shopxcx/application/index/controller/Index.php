<?php
namespace app\index\controller;

use app\lib\exception\ApiException;
use app\lib\exception\ErrorCode;
use think\facade\Cache;

class Index
{
    public function index()
    {
        throw new ApiException(ErrorCode::$E40003);
    }

    public function hello($name = 'ThinkPHP5')
    {
        return 'hello,' . $name;
    }
}
