<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/18
 * Time: 9:35 PM
 */
phpinfo();