<?php
/**
 * Created by PhpStorm.
 * User: ycbwl
 * Date: 2018/10/23
 * Time: 12:34 AM
 */
return [
    'img_prefix'=>'http://shopxcx.com/images'
];